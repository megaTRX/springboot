package com.springboot.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Repository;

import com.springboot.domain.Clothes;

@Repository 
public class ClothesRepositoryImpl implements ClothesRepository {

    // DB 역할을 할 메모리 상의 리스트
    private List<Clothes> listOfClothes = new ArrayList<>();

    // 생성자: 객체 생성 시 샘플 데이터를 리스트에 추가
    public ClothesRepositoryImpl() {
        Clothes c1 = new Clothes();
        c1.setClothesId("ISBN1234"); 
        c1.setName("서울 티셔츠");
        c1.setUnitPrice(new BigDecimal("25000"));
        c1.setStoreName("서울스토어");
        c1.setDescription("편안한 면 티셔츠입니다.");
        c1.setCategory("Top"); // 상의
        c1.setUnitsInStock(100);
        c1.setCondition("New");
        c1.setFileName("tshirt.png");

        Clothes c2 = new Clothes();
        c2.setClothesId("ISBN1235");
        c2.setName("부산 자켓");
        c2.setUnitPrice(new BigDecimal("89000"));
        c2.setStoreName("부산패션");
        c2.setDescription("가을에 입기 좋은 자켓");
        c2.setCategory("Outer"); // 아우터
        c2.setUnitsInStock(50);
        c2.setCondition("Old"); // 중고 예시
        c2.setFileName("jacket.png");

        Clothes c3 = new Clothes();
        c3.setClothesId("ISBN1236");
        c3.setName("제주 청바지");
        c3.setUnitPrice(new BigDecimal("45000"));
        c3.setStoreName("제주진");
        c3.setDescription("스판끼 있는 청바지");
        c3.setCategory("Bottom"); // 하의
        c3.setUnitsInStock(1000);
        c3.setCondition("New");
        c3.setFileName("jeans.png");

        listOfClothes.add(c1);
        listOfClothes.add(c2);
        listOfClothes.add(c3);
    }

	@Override
	public List<Clothes> getAllClothesList() {
		// TODO Auto-generated method stub
		return listOfClothes;
	}

	@Override
	public List<Clothes> getClothesListByCategory(String category) {
	    List<Clothes> clothesByCategory = new ArrayList<Clothes>();
	    
	    // 리스트에 있는 모든 옷을 하나씩 검사
	    for (int i = 0; i < listOfClothes.size(); i++) {
	        Clothes clothes = listOfClothes.get(i);
	        
	        // 대소문자 구분 없이 카테고리가 일치하는지 확인 (예: top == Top)
	        if (category.equalsIgnoreCase(clothes.getCategory())) {
	            clothesByCategory.add(clothes); // 일치하면 결과 리스트에 담기
	        }
	    }
	    
	    return clothesByCategory;
	}

	@Override
	public Set<Clothes> getClothesListByFilter(Map<String, List<String>> filter) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Clothes getClothesById(String clothesId) {
	    Clothes clothesById = null;
	    
	    // 리스트를 순회하며 ID가 일치하는 옷을 찾음
	    for (int i = 0; i < listOfClothes.size(); i++) {
	        Clothes clothes = listOfClothes.get(i);
	        if (clothes != null && clothes.getClothesId() != null && 
	            clothes.getClothesId().equals(clothesId)) {
	            clothesById = clothes;
	            break;
	        }
	    }
	    return clothesById;
	}

	@Override
	public void setNewClothes(Clothes clothes) {
		// TODO Auto-generated method stub
		
		listOfClothes.add(clothes);
		
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <S extends Clothes> S saveAndFlush(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> List<S> saveAllAndFlush(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAllInBatch(Iterable<Clothes> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllByIdInBatch(Iterable<String> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Clothes getOne(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Clothes getById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Clothes getReferenceById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> List<S> findAll(Example<S> example) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> List<S> findAll(Example<S> example, Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> List<S> saveAll(Iterable<S> entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Clothes> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Clothes> findAllById(Iterable<String> ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> S save(S entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Clothes> findById(String id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public boolean existsById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Clothes entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllById(Iterable<? extends String> ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends Clothes> entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Clothes> findAll(Sort sort) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Clothes> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> Optional<S> findOne(Example<S> example) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public <S extends Clothes> Page<S> findAll(Example<S> example, Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Clothes> long count(Example<S> example) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Clothes> boolean exists(Example<S> example) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <S extends Clothes, R> R findBy(Example<S> example, Function<FetchableFluentQuery<S>, R> queryFunction) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Clothes> findByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Clothes> findByNameContaining(String name) {
		// TODO Auto-generated method stub
		return null;
	}


}