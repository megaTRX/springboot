package com.springboot.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.domain.Clothes;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface ClothesRepository extends JpaRepository<Clothes, String> {
	
	List<Clothes> getAllClothesList(); 
	
	List<Clothes> getClothesListByCategory(String category);
	
	Set<Clothes> getClothesListByFilter(Map<String, List<String>> filter);
	
	Clothes getClothesById(String clothesId);
	
	void setNewClothes(Clothes clothes);
	
	// 카테고리로 찾기 (SELECT * FROM clothes WHERE category = ?)
    List<Clothes> findByCategory(String category);
    
    // 이름으로 검색 기능이 필요하다면 추가 가능
    List<Clothes> findByNameContaining(String name);

}
