package com.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.domain.CartItem;

// JpaRepository<엔티티, PK타입>을 상속받으면 자동으로 DB 연결 기능이 생성됩니다.
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    // 이미 장바구니에 있는 옷인지 확인하는 메서드 자동 생성
    CartItem findByClothesId(String clothesId);
}