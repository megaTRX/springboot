package com.springboot.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

/**
 * Person 엔티티 클래스
 * 데이터베이스의 Person 테이블과 매핑되며, Spring Security의 UserDetails 인터페이스를 구현하지 않고
 * 별도의 어댑터 패턴을 사용하는 것이 일반적이나, 단순함을 위해 도메인 객체 내에 로직을 포함하거나
 * 별도의 UserDetails 구현체를 둔다. 본 예제에서는 SRP(단일 책임 원칙) 준수를 위해 
 * 엔티티는 순수 데이터 구조로 남겨두고 별도의 SecurityUser 클래스를 래퍼(Wrapper)로 사용한다.
 */
@Entity
@Table(name = "Person")
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED) // JPA 스펙상 기본 생성자 필수 (protected 권장)
public class Person {

    @Id
    @Column(name = "id", nullable = false, length = 45)
    private String id; // Username 역할을 수행

    // 아키텍처 결정: 실제 DB 스키마는 45자이지만, 코드상으로는 길이 제약을 유연하게 두거나 
    // DDL Auto 옵션으로 스키마 변경을 유도하기 위해 length 설정을 조정할 수 있음.
    // 하지만 기존 스키마 준수를 위해 어노테이션은 45로 하되, 실제로는 60자 이상이 필요함.
    @Column(name = "password", nullable = false, length = 60) // BCrypt 대응을 위해 60으로 매핑
    private String password;

    @Column(name = "name", nullable = false, length = 45)
    private String name;

    @Column(name = "age", nullable = false)
    private int age;

    @Column(name = "email", nullable = false, length = 45)
    private String email;

    @Builder
    public Person(String id, String password, String name, int age, String email) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.age = age;
        this.email = email;
    }
}