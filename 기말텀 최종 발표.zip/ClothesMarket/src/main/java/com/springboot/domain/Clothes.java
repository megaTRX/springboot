package com.springboot.domain;

import java.math.BigDecimal;

import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;



@Entity // 1. 이 클래스는 DB 테이블과 매핑된다고 선언
@Table(name = "clothes")
@Data
public class Clothes {
	@Pattern(regexp="ISBN[1-9]+")
	
	@Id // 3. 기본키(PK) 설정
    @Column(name = "clothes_id")
	private String clothesId; // 도서ID
	
	@Size(min=4, max=50)
	private String name;
	
	@Min(value=0)
	@Digits(integer=8, fraction=2)
	@NotNull
	
	@Column(name = "unit_price")
	private BigDecimal unitPrice; // 가격
	
	@Column(name = "store_name")
	private String storeName; // 스토어명
	
	private String description; // 설명
	
	private String category; // 분류
	
	@Column(name = "units_in_stock")
	private long unitsInStock; // 재고수
	
	@Column(name = "release_date")
	private String releaseDate; // 출시일
	
	@Column(name = "condition_status")
	private String condition; // 상태
	
	@Column(name = "file_name")
	private String fileName; // 옷 이미지 파일
	
	@Transient
	private MultipartFile clothesImage; // 옷 이미지
	
	

}
