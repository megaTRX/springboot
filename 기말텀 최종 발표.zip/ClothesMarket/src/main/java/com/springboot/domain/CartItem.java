package com.springboot.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cart_item")
@Data
@NoArgsConstructor
public class CartItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; 

    @Column(name = "clothes_id")
    private String clothesId; 

    private int quantity; 

    // [추가] DB에는 저장되지 않지만, 화면 표시를 위해 옷 정보를 담을 필드
    @Transient 
    private Clothes clothes; 

    // [추가] 총 가격 계산 로직 (수량 * 단가)
    public double getTotalPrice() {
        if (clothes != null && clothes.getUnitPrice() != null) {
            return clothes.getUnitPrice().doubleValue() * quantity;
        }
        return 0.0;
    }

    public CartItem(String clothesId, int quantity) {
        this.clothesId = clothesId;
        this.quantity = quantity;
    }
    
   
}