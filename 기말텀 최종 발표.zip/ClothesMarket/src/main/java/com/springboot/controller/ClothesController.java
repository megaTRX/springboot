package com.springboot.controller;

import java.io.File;
import java.io.IOException; 
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.domain.CartItem;
import com.springboot.domain.Clothes;
import com.springboot.service.ClothesService;
import com.springboot.service.CartService;
import com.springboot.domain.CartItem;

import jakarta.validation.Valid;
import com.springboot.domain.CartItem;


@Controller
@RequestMapping(value = "/clothes")
public class ClothesController {
	
	@Autowired
	private ClothesService clothesService;
	
	@Autowired
    private CartService cartService;
	
	@Value("${file.uploadDir}")
	String fileDir;
	
	@GetMapping
	public String requestClothesList(Model model) {
		List<Clothes> list = clothesService.getAllClothesList();
		model.addAttribute("clothesList", list); // addAllAttributes -> addAttribute
		return "wear";
	}
	
	@GetMapping("/all")
	public ModelAndView requestAllClothes() { // 메서드 명 변경 (Books -> Clothes)
		ModelAndView modelAndView = new ModelAndView(); // 오타 수정 (modelAndViewe -> modelAndView)
		List<Clothes> list = clothesService.getAllClothesList(); // Static 호출 수정 (ClothesService -> clothesService)
		modelAndView.addObject("clothesList", list);
		modelAndView.setViewName("wear");
		return modelAndView;
	}
	
	// com.springboot.controller.ClothesController.java

	@GetMapping("{category}")
	public String requestClothesByCategory(@PathVariable("category") String clothesCategory, Model model) {
	    // 1. 서비스에서 카테고리에 맞는 리스트 가져오기
	    List<Clothes> clothesByCategory = clothesService.getClothesListByCategory(clothesCategory);
	    
	    // 2. 예외 처리 코드 삭제 (옷이 없어도 에러가 나지 않도록)
	    // if (clothesByCategory == null || clothesByCategory.isEmpty()) { ... }  <-- 이 부분 삭제 또는 주석 처리
	    
	    // 3. 모델에 담아서 뷰로 전달
	    model.addAttribute("clothesList", clothesByCategory);
	    
	    return "wear"; // wear.html (상품 목록 페이지)로 이동
	}
	
	@GetMapping("/filter/{clothesFilter}")
	public String requestClothesByFilter(
			@MatrixVariable(pathVar="clothesFilter") Map<String, List<String>> clothesFilter, 
			Model model) { 
		Set<Clothes> clothesByFilter = clothesService.getClothesListByFilter(clothesFilter); 
		model.addAttribute("clothesList", clothesByFilter);
		return "wear";
	}
	
	@GetMapping("/detail") // 주소: /clothes/detail
	public String requestClothesById(@RequestParam("id") String clothesId, Model model) {
	    
	    // 1. 콘솔에 로그 찍어보기 (서버 밑에 로그창 확인)
	    System.out.println("요청된 ID: " + clothesId);

	    Clothes clothesById = clothesService.getClothesById(clothesId);
	    
	    // 2. 데이터가 잘 왔는지 확인
	    if (clothesById == null) {
	        System.out.println("오류: 해당 ID의 옷을 찾을 수 없습니다 (Null).");
	        return "redirect:/clothes"; // 없으면 목록으로 튕겨내기
	    }
	    
	    System.out.println("찾은 옷 이름: " + clothesById.getName());

	    model.addAttribute("clothes", clothesById);
	    return "clothes"; // templates/clothes.html 파일을 찾음
	}
	
	
	
	@GetMapping("/add")
	public String requestAddClothesForm(Model model) {
		model.addAttribute("clothes", new Clothes()); // 클래스 생성자 대문자로 수정
		return "addClothes";
	}
	
	@PostMapping("/add")
	public String submitAddNewClothes(@Valid @ModelAttribute Clothes clothes, BindingResult bindingResult) {
	    if(bindingResult.hasErrors()) {
	        return "addClothes";
	    }
	    
	    MultipartFile clothesImage = clothes.getClothesImage();
	    
	    // 파일이 존재할 때만 이름 추출 및 저장소 파일 객체 생성
	    if (clothesImage != null && !clothesImage.isEmpty()) {
	        String saveName = clothesImage.getOriginalFilename(); // 여기서 변수 선언
	        File saveFile = new File(fileDir, saveName);          // 여기서 객체 생성
	        
	        try {
	            clothesImage.transferTo(saveFile);
	            clothes.setFileName(saveName); 
	        } catch (Exception e) {
	            throw new RuntimeException("옷 이미지 업로드가 실패하였습니다.", e);
	        }
	    }
	    
	    clothesService.setNewClothes(clothes); 
	    
	    return "redirect:/clothes"; 
	}
	

    @ModelAttribute 
    public void addAttributes(Model model) { 
        model.addAttribute("addTitle", "신규 옷 등록");
    }
    

   
    @GetMapping("/clothes/register")
    public String registerPage() {
        return "clothes/register"; // templates/clothes/register.html 렌더링
    }
    
 
    @PostMapping("/clothes/register")
    public String registerClothes() {
        //... 의류 등록 비즈니스 로직 수행...
        return "redirect:/clothes/list";
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }
    
    @PostMapping("/cart/add/{id}")
    public String addToCart(@PathVariable("id") String clothesId) {
        
        // 서비스 호출하여 DB에 저장
        cartService.addCart(clothesId);
        
        // 장바구니 목록 페이지로 이동
        return "redirect:/clothes/cart";
    }


    @GetMapping("/cart")
    public String requestCartList(Model model) {
        // 1. 서비스에서 장바구니 목록 가져오기
        List<CartItem> cartList = cartService.getCartList();
        
        // 2. 총 결제 금액 계산 로직 추가
        double grandTotal = 0;
        for (CartItem item : cartList) {
            grandTotal += item.getTotalPrice(); // 각 항목의 합계를 누적
        }

        // 3. 모델에 담아서 화면으로 전달
        model.addAttribute("cartList", cartList);
        model.addAttribute("grandTotal", grandTotal); // <-- 이 부분이 핵심입니다!
        
        return "cart";
    }
    

    @PostMapping("/cart/update")
    public String updateCartQuantity(@RequestParam("cartId") Long cartId, 
                                     @RequestParam("quantity") int quantity) {
        cartService.updateQuantity(cartId, quantity);
        return "redirect:/clothes/cart";
    }
    

    @GetMapping("/cart/delete/{id}")
    public String deleteCartItem(@PathVariable("id") Long cartId) {
        cartService.deleteCartItem(cartId);
        return "redirect:/clothes/cart";
    }
    
 // 기존 코드 아래에 추가

  
    @GetMapping("/order") 
    public String processOrder() {
        cartService.clearCart(); 
        
 
        return "orderSuccess";   
    }
    
    
    
}