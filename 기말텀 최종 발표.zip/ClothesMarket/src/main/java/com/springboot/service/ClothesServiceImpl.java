package com.springboot.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.domain.Clothes;
import com.springboot.repository.ClothesRepository;

@Service
public class ClothesServiceImpl implements ClothesService {
	
	
	@Autowired
	private ClothesRepository clothesRepository;

	public List<Clothes> getAllClothesList() {
		return clothesRepository.getAllClothesList();
	}
	
	public List<Clothes> getClothesListByCategory(String category) { 
	      List<Clothes> clothesByCategory = clothesRepository.getClothesListByCategory(category); 
	      return clothesByCategory;  
	}	
	
	public Set<Clothes> getClothesListByFilter(Map<String, List<String>> filter) {
	      Set<Clothes> clothesByFilter = clothesRepository.getClothesListByFilter(filter); 
	      return clothesByFilter;
	}
	
	public Clothes getClothesById(String clothesId) {
	   //  Clothes clothesById = clothesRepository.getClothesById(clothesId);
	     return clothesRepository.getClothesById(clothesId);
	}	
	 public void setNewClothes(Clothes clothes) { 
		    clothesRepository.setNewClothes(clothes); 
		 }
	 
}
