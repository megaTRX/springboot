package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.domain.CartItem;
import com.springboot.domain.Clothes; // 옷 정보 매핑을 위해 필요
import com.springboot.repository.CartItemRepository;

@Service
@Transactional
public class CartService {

    @Autowired
    private CartItemRepository cartItemRepository;
    
    @Autowired
    private ClothesService clothesService; // 옷 정보 가져오기 위해 주입

    // 1. 장바구니 담기
    public void addCart(String clothesId) {
        CartItem cartItem = cartItemRepository.findByClothesId(clothesId);

        if (cartItem == null) {
            cartItem = new CartItem(clothesId, 1);
            cartItemRepository.save(cartItem);
        } else {
            cartItem.setQuantity(cartItem.getQuantity() + 1);
        }
    }

    // 2. 장바구니 목록 가져오기 (옷 정보 포함)
    public List<CartItem> getCartList() {
        List<CartItem> cartItems = cartItemRepository.findAll();
        
        for (CartItem item : cartItems) {
            // ID를 이용해 옷 상세 정보를 가져와서 세팅
            Clothes clothes = clothesService.getClothesById(item.getClothesId());
            item.setClothes(clothes);
        }
        return cartItems;
    }
    
    // 3. 수량 변경
    public void updateQuantity(Long cartItemId, int quantity) {
        CartItem cartItem = cartItemRepository.findById(cartItemId)
                .orElseThrow(() -> new IllegalArgumentException("해당 장바구니 항목이 없습니다."));
        
        if (quantity <= 0) {
             cartItemRepository.delete(cartItem); 
        } else {
            cartItem.setQuantity(quantity);
        }
    }

    // 4. 개별 항목 삭제
    public void deleteCartItem(Long cartItemId) {
        cartItemRepository.deleteById(cartItemId);
    }
    
    // 5. 장바구니 비우기 (주문 완료 시 사용)
    public void clearCart() {
        cartItemRepository.deleteAll(); 
    }
}