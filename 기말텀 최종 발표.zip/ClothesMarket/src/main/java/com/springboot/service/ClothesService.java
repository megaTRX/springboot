package com.springboot.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.springboot.domain.Clothes;

public interface ClothesService {
	
	List<Clothes> getAllClothesList();
	List<Clothes> getClothesListByCategory(String category);
	Set<Clothes> getClothesListByFilter(Map<String, List<String>> filter);
	Clothes getClothesById(String clothesId);
	void setNewClothes(Clothes clothes);

}
