package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chap07Application {

	public static void main(String[] args) {
		SpringApplication.run(Chap07Application.class, args);
	}

}
