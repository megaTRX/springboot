package com.springboot.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.domain.Member;

@Controller
@RequestMapping("/exam03")
public class Example03Controller {
	
	@GetMapping("/form")
	public String requestForm(Member member) {
		return "viewPage";
	}

	@PostMapping("/form")
	public String submitForm(@ModelAttribute Member member, Model model){	
        String name = member.getName();
        MultipartFile file = member.getFileImage();
        
        String filename = file.getOriginalFilename();  
        File saveFile = new File("c:\\upload\\" + name + "_" + filename);  
        try {
        	file.transferTo(saveFile);
        	
        	model.addAttribute("data1","@ModelAttribute 예졔" );
			model.addAttribute("data2",filename);
			model.addAttribute("data3", saveFile.getName() );
			
        }catch (IOException e) {            
            e.printStackTrace();
        }
		return "viewPage_process";
	}
}