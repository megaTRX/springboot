package com.springboot.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@Controller
@RequestMapping("/exam01")
public class Example01Controller {
	
	@GetMapping("/form")
	public String requestForm() {
		return "viewPage";
	}
	
	@PostMapping("/form")
    public String submitForm(MultipartHttpServletRequest request, Model model){
       
        String name = request.getParameter("name");
        MultipartFile file = request.getFile("fileImage");
        
        String filename   = file.getOriginalFilename();
         
        File saveFile = new File("c:\\upload\\" + name + "_" + filename );

		try {
			file.transferTo(saveFile);
			model.addAttribute("data1","MultipartHttpServletRequest 예졔" );
			model.addAttribute("data2",filename);
			model.addAttribute("data3", saveFile.getName() );
		} catch (IOException e) {
			e.printStackTrace();
		}        
        return "viewPage_process";
    }	
	
	
}