package com.springboot.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.io.OutputStream;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/exam04")
public class Example04Controller {
	
	@GetMapping
	public String photoDownload(Model model)
	{
		return "viewPage02";
	}
	@GetMapping("/download")
	public void photoDownload(@RequestParam("file") String paramKey,                         
	                         HttpServletResponse response) throws IOException {

	      
	    File f = new File("c:\\upload\\" + paramKey );	
        // file 다운로드 설정
        response.setContentType("application/download");
        response.setContentLength((int)f.length());
        response.setHeader("Content-disposition", "attachment;filename=\"" + paramKey + "\"");
        // response 객체를 통해서 서버로부터 파일 다운로드
        OutputStream os = response.getOutputStream();
        // 파일 입력 객체 생성
        FileInputStream fis = new FileInputStream(f);
        FileCopyUtils.copy(fis, os);
        fis.close();
        os.close();
        
	    }
}