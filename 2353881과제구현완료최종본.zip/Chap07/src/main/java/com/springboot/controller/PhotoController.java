package com.springboot.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import com.springboot.domain.Photo;

@Controller
@RequestMapping("/photo")
public class PhotoController {
	@GetMapping("/upload")
	public String requestForm(Photo photo) {
		return "photoUploadForm"; 
	}

	@PostMapping("/upload")
	public String submitForm(@ModelAttribute Photo photo, Model model) {
		String title = photo.getTitle();
		MultipartFile file = photo.getImageFile();
		String description = photo.getDescription();
		String originFilename = file.getOriginalFilename();
	      File saveFile = new File("C:\\upload\\" +originFilename);
		try {
			file.transferTo(saveFile);
			 model.addAttribute("title", title);
	         model.addAttribute("description", description);
	         model.addAttribute("imageUrl","/images/"+saveFile.getName());
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return "photoUploadResult";
	}

	
	
}
