package com.springboot.domain;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class Photo {
	private String title;           // 이미지 제목
    private String description;     // 이미지 설명
    private MultipartFile imageFile; // 업로드 파일

}
