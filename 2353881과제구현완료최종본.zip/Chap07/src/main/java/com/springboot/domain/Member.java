package com.springboot.domain;


import org.springframework.web.multipart.MultipartFile;

import lombok.Data;


@Data
public class Member {
	 private String name;
	 private MultipartFile fileImage;
}
