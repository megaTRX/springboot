package com.springboot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ResourceConfig implements WebMvcConfigurer {	
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		 registry.addResourceHandler("/images/**")
         .addResourceLocations("file:///C:/upload/");
	}
	/*
	// 리눅스 경우 root에서 시작하는 폴더 경로 지정 할 경우 
	.addResourceLocations("file:///usr/download/") 

	// 리소스 템플릿 경로를 지정할 경우
	.addResourceLocations("classpath:/templates/", "classpath:/static/")

	// 윈도우에서 실행 시 다음과 같은 형태로 드라이브 문자 포함 경로 지정 
	.addResourceLocations("file:///E:/webserver_storage/")
	*/
}
