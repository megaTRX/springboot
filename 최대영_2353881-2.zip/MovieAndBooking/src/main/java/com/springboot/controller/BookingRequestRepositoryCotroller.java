package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springboot.domain.BookingRequest;
import com.springboot.service.PaymentService;

@Controller
public class BookingRequestRepositoryCotroller {
	@Autowired
	private PaymentService paymentservice;
	@RequestMapping(value = "/payment", method = RequestMethod.GET)
	public String requestBookingRequestList (Model model) {
		List<BookingRequest> list = paymentservice.processPayment();
		model.addAttribute("bookingRequestList", list);
		return "payment";
	}

}
