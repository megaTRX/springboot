package com.springboot.service;

import java.util.List;

import com.springboot.domain.Booking;

public interface BookingService {
	List<Booking> getAllBookingList();

}
