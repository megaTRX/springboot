package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.domain.Booking;
import com.springboot.domain.BookingRequest;
import com.springboot.repository.BookingRepository;
import com.springboot.repository.BookingRequestRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	public List<Booking> getAllBookingList() {
		// TODO Auto-generated method stub
		return bookingRepository.getAllBookingList();
	}

	private BookingRequestRepository bookingRequestRepository;
	public List<BookingRequest> processPayment() {
		return bookingRequestRepository.processPayment();
	}
}
