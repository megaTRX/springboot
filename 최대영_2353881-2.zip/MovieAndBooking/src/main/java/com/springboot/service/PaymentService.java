package com.springboot.service;

import java.util.List;

import com.springboot.domain.BookingRequest;

public interface PaymentService {
	List<BookingRequest> processPayment();
}
