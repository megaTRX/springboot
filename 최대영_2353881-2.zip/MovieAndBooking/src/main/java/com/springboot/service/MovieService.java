package com.springboot.service;

import java.util.List;

import com.springboot.domain.Movie;

public interface MovieService {
	List<Movie> getAllMovies();
}
