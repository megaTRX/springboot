package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.domain.Movie;
import com.springboot.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository movieRepository;
	public List<Movie> getAllMovies() {
		// TODO Auto-generated method stub
		return movieRepository.getAllMovies();
	}

}
