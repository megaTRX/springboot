package com.springboot.repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springboot.domain.Booking;
import com.springboot.domain.BookingRequest;

@Repository
public class BookingRepositoryImpl implements BookingRepository {

	private List<Booking> listOfBookings = new ArrayList<Booking>();
	public BookingRepositoryImpl() {
		Booking booking1 = new Booking();
		booking1.setBookingId("4관 B-2");
		booking1.setMemberId("샹견니");
		booking1.setShowingId("2025년 9월 1일");
		booking1.setPrice(new BigDecimal(15000));
		
		Booking booking2 = new Booking();
		booking2.setBookingId("5관 C-1");
		booking2.setMemberId("건축학개론");
		booking2.setShowingId("2025년 8월 21일");
		booking2.setPrice(new BigDecimal(13000));
		
		Booking booking3 = new Booking();
		booking3.setBookingId("3관 G-21");
		booking3.setMemberId("파묘");
		booking3.setShowingId("2025년 7월 21일");
		booking3.setPrice(new BigDecimal(22000));
		
		listOfBookings.add(booking1);
		listOfBookings.add(booking2);
		listOfBookings.add(booking3);
	}
	



	@Override
	public List<Booking> getAllBookingList() {
		// TODO Auto-generated method stub
		return listOfBookings;
	}}
