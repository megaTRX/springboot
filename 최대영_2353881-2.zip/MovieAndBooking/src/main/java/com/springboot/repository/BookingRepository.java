package com.springboot.repository;

import java.util.List;

import com.springboot.domain.Booking;

public interface BookingRepository {
	List<Booking> getAllBookingList();
}
