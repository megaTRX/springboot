package com.springboot.repository;

import java.util.List;

import com.springboot.domain.BookingRequest;

public interface BookingRequestRepository {
	List<BookingRequest> processPayment();
}
