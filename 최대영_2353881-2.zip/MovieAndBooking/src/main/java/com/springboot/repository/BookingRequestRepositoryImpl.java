package com.springboot.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springboot.domain.BookingRequest;

@Repository
public class BookingRequestRepositoryImpl implements BookingRequestRepository {
	
	private List<BookingRequest> listOfRequests = new ArrayList<BookingRequest>();
	private BookingRequestRepositoryImpl() {
		BookingRequest Request1 = new BookingRequest();
		Request1.setMemberId("샹견니");
		Request1.setShowingId("서울");
		Request1.setSeatIds("CGV-Screen3-C10");
		Request1.setPaymentMethod("카카오페이");
		
		BookingRequest Request2 = new BookingRequest();
		Request2.setMemberId("건축학개론");
		Request2.setShowingId("부산");
		Request2.setSeatIds("MegaBox-8-B-7");
		Request2.setPaymentMethod("체크카드");
		
		BookingRequest Request3 = new BookingRequest();
		Request3.setMemberId("파묘");
		Request3.setShowingId("대구");
		Request3.setSeatIds("LOTTE-2-C-5");
		Request3.setPaymentMethod("현금");
		
		listOfRequests.add(Request1);
		listOfRequests.add(Request2);
		listOfRequests.add(Request3);
		
		
	}

	@Override
	public List<BookingRequest> processPayment() {
		// TODO Auto-generated method stub
		return listOfRequests;
	}

}
