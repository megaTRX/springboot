package com.springboot.repository;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springboot.domain.Movie;

@Repository
public class MovieRepositoryImpl implements MovieRepository {

	@Override
	public List<Movie> getAllMovies() {
		// TODO Auto-generated method stub
		return listOfMovies;
	}
	
	private List<Movie> listOfMovies = new ArrayList<Movie>();
	public MovieRepositoryImpl() {
		Movie movie1 = new Movie();
		movie1.setName("샹견니");
		movie1.setUnitPrice(new BigDecimal(15000));
		movie1.setDirector("황천인");
		movie1.setDesciption("대만에서 큰 인기를 얻은 타임슬립 로맨스 드라마와 이를 확장한 영화입니다. 복잡하게 얽힌 시간 여행과 등장인물들의 관계가 특징이며, 많은 '상친자'(상견니에 미친 자들)를 양산할 만큼 큰 사랑을 받았습니다.");
		movie1.setCompany("삼봉");
		movie1.setCategory("로맨스");    
		movie1.setAudienceCount(387574);
		movie1.setReleaseDate("2023년 1월 25일");
		
		Movie movie2 = new Movie();
		movie2.setName("건축학개론");
		movie2.setUnitPrice(new BigDecimal(8000));
		movie2.setDirector("이용주");
		movie2.setDesciption("이 영화는 두 주인공인 '승민'과 '서연'의 15년 전과 현재를 교차하며 그들의 첫사랑 이야기를 그려냅니다.");
		movie2.setCompany("명필름");
		movie2.setCategory("멜로");
		movie2.setAudienceCount(4112233);
		movie2.setReleaseDate("2012년 3월 22일");
		
		Movie movie3 = new Movie();
		movie3.setName("파묘");
		movie3.setUnitPrice(new BigDecimal(13000));
		movie3.setDirector("장재현");
		movie3.setDesciption("이 영화는 거액의 의뢰를 받은 무당, 풍수사, 장의사가 한 가족의 묘를 이장하면서 벌어지는 기이한 사건들을 다룹니다.");
		movie3.setCompany("쇼박스");
		movie3.setCategory("스릴러");
		movie3.setAudienceCount(11914798);
		movie3.setReleaseDate("2024년 2월 22일");
		
		listOfMovies.add(movie1);
		listOfMovies.add(movie2);
		listOfMovies.add(movie3);
		
	}
	

}
