package com.springboot.domain;

public class BookingRequest {
	private String memberId; // 회원 ID
	private String showingId; // 상영 ID
	private String seatIds; // 좌석 ID
	private String paymentMethod; // 결제 수단
	
	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getShowingId() {
		return showingId;
	}

	public void setShowingId(String showingId) {
		this.showingId = showingId;
	}

	public String getSeatIds() {
		return seatIds;
	}

	public void setSeatIds(String seatIds) {
		this.seatIds = seatIds;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public BookingRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

}
