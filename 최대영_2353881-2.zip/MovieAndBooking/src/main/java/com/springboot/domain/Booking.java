package com.springboot.domain;

import java.math.BigDecimal;

public class Booking {
	private String bookingId; // 예약 ID
	private String memberId; // 회원 ID
	private String showingId; // 상영 ID
	private BigDecimal price; // 결제 금액
	
	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getShowingId() {
		return showingId;
	}

	public void setShowingId(String showingId) {
		this.showingId = showingId;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
}
