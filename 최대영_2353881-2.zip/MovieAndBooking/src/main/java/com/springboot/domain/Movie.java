package com.springboot.domain;

import java.math.BigDecimal;

public class Movie {
	private String name; // 영화 제목
	private BigDecimal unitPrice; // 가격
	private String director; // 감독
	private String desciption; // 설명
	private String company; // 회사
	private String category; // 분류
	private long audienceCount; // 관객수
	private String releaseDate; // 개봉일(월/년)
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getDesciption() {
		return desciption;
	}

	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public long getAudienceCount() {
		return audienceCount;
	}

	public void setAudienceCount(long audienceCount) {
		this.audienceCount = audienceCount;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}

}
